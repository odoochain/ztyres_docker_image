# -*- coding: utf-8 -*-

from . import product_product
from . import stock_location
from . import stock_quant